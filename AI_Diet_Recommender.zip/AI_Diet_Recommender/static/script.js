document.getElementById("dietForm").addEventListener("submit", async function(e) {
    e.preventDefault();

    const age = document.getElementById("age").value;
    const weight = document.getElementById("weight").value;
    const height = document.getElementById("height").value;
    const gender = document.getElementById("gender").value;
    const lifestyle = document.getElementById("lifestyle").value;

    const response = await fetch("/predict", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ age, weight, height, gender, lifestyle })
    });

    const result = await response.json();
    document.getElementById("results").innerHTML = `
        <div class="result-card"><strong>BMI:</strong> ${result.bmi.toFixed(2)}</div>
        <div class="result-card"><strong>BMR:</strong> ${result.bmr.toFixed(2)}</div>
        <div class="result-card"><strong>Calories Needed:</strong> ${result.calories.toFixed(0)} kcal</div>
        <div class="result-card"><strong>Suggested Diet Plan:</strong> ${result.diet}</div>
    `;
});
