from flask import Flask, render_template, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

def calculate_bmi(weight, height_cm):
    height_m = height_cm / 100
    return weight / (height_m ** 2)

def calculate_bmr(gender, weight, height, age):
    if gender == 'male':
        return 10 * weight + 6.25 * height - 5 * age + 5
    else:
        return 10 * weight + 6.25 * height - 5 * age - 161

def get_calorie_needs(bmr, lifestyle):
    activity_multipliers = {'sedentary': 1.2, 'moderate': 1.55, 'active': 1.75}
    return bmr * activity_multipliers.get(lifestyle, 1.2)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    age = int(data['age'])
    weight = float(data['weight'])
    height = float(data['height'])
    gender = data['gender']
    lifestyle = data['lifestyle']

    bmi = calculate_bmi(weight, height)
    bmr = calculate_bmr(gender, weight, height, age)
    calories = get_calorie_needs(bmr, lifestyle)

    if bmi >= 30:
        diet = "Weight Loss"
    elif bmi <= 18.5:
        diet = "Weight Gain"
    else:
        diet = "Maintenance"

    return jsonify({
        'bmi': bmi,
        'bmr': bmr,
        'calories': calories,
        'diet': diet
    })

if __name__ == '__main__':
    app.run(debug=True)
